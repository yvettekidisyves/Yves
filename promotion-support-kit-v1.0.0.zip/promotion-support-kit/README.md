# 大促支持通用技能包 · v1.0.0

适用于大促期间午晚餐、咖啡及已授权的后勤物资支持，覆盖需求→收集→点餐→费用截图→发票复盘。含1个总控＋6个可独立使用的子技能、6个仅本地计算的Python脚本，以及空模板和合成示例。此包不含真实群ID、姓名、地址、订单、发票或登录凭证。

## 安装与分享

把本文件夹或ZIP发给接收方。接收方解压，将`skills/`里的七个文件夹放到其运行环境的技能目录，保持相邻关系；Codex常用位置为`~/.codex/skills/`，实际按所在工作区和宿主规定选择。已有同名技能先比较/备份，再决定替换，尤其`feishu-meituan-lunch`。刷新技能发现方式以宿主当前文档为准。本包没有执行安装、连接账号或创建自动化。

也可单独使用子技能。需要跨模块复用时完整安装更方便；若缺少可选兄弟技能，按该模块的文字流程执行，别猜缺失脚本存在。不要把整个外层`promotion-support-kit`误当一个技能：每个含`SKILL.md`的子目录才是技能。

入口：[总控SKILL](skills/promotion-support/SKILL.md)；人工阅读：[全流程SOP](全流程SOP.md)。

## 示例指令

- “用 $promotion-support 整理下周大促支持。先收集需求并列执行计划，发群和付款等我确认。”
- “用 $feishu-meituan-lunch 查看今天可配送的最近分店，选10个候选。投票后按实际票数加购，20分钟给我核对，25分钟报告状态。”
- “用 $coffee-batch-ordering 统计全部接龙，上午下午、两个配送地点分列；先准备上午购物车，我付款后再准备下午。”
- “用 $order-cost-archive 汇总这些正式订单，按实付和到账退款算净支出，保存截图到现有文档。”
- “用 $invoice-reconciliation 补充邮箱中已有发票，按票号去重，保留未确认覆盖与差额。”

## 能力与权限

本地计算只需Python 3.9+标准库。飞书读写需实际可用的飞书技能/CLI或连接器、用户登录和文档权限；原生投票/接龙需客户端界面控制能力，不能用替代卡片冒充。手机美团需实际可用的设备控制；已验证环境为macOS的iPhone镜像，但不是通用手机API。邮箱、文档和PDF读取调用环境现有对应技能，不内置账号和平台凭证。不具备相应工具时仍可输出计划/统计，但明确未执行。

工具命令和界面可能变化，先读当前工具文档。支持中国境内美团/飞书路径，并不声称所有地区或客户端版本都可操作。配置中的时区、实际门店、人数、销售单位、饮品规格、地点和授权每次动态输入。

## 25分钟目标

每次点餐请求20分钟交付核对购物车，留5分钟审核；15分钟预计赶不上提前交接，25分钟给真实状态。检查、等待、认证和断连都计入，不在分单间重置；用户明确要求继续则继续。跨日活动不承诺整场25分钟结束，历史执行也未证明每次均达标。

## 本地工具试用

所有命令均只处理文件，不发布消息、不加购、不付款。先在当前项目内复制合成示例再修改，输出也保存到该项目。命令以下以技能目录为当前目录：

```text
coffee-batch-ordering：python3 scripts/group_orders.py assets/coffee.synthetic.json
order-cost-archive：python3 scripts/summarize_orders.py assets/orders.synthetic.json
invoice-reconciliation：python3 scripts/reconcile_invoices.py ../order-cost-archive/assets/orders.synthetic.json assets/invoices.synthetic.json
feishu-meituan-lunch：python3 scripts/allocate_drinks.py 本次饮品输入.json
feishu-meituan-lunch：python3 scripts/plan_cart.py 本次SKU输入.json --observed 实际购物车.json
feishu-meituan-lunch：python3 scripts/budget.py start 本次计时.json --started-at 实际含时区开始时间
```

费用/发票命令第三条接受原始账本或汇总文件。退出0仅代表所提供数据的计算/检查通过；退出2表示输入/待核事项，绝不等于平台执行状态。具体字段见各SKILL相对链接。

验证范围见[验证说明](验证说明.md)。MANIFEST.json记录包内原件哈希；不附真实项目样本。使用者新增私有数据后，不要把整个使用目录直接再分享。
