# 发票核对输入

参考[合成示例](../assets/invoices.synthetic.json)。订单可用费用技能的原始账本（完整安装时自动调用本地汇总）或已有汇总JSON。独立安装传汇总：currency、net_total（金额字符串）、complete（实际完整核验时true）、orders（含order_id列表）。

发票文件包含currency、invoices、potential_overlaps。每张正式票包含：

- invoice_number：正式数字字符串，保留前导0和长票号；不会强制固定20位以兼容不同票种。
- kind：invoice；收据用receipt并单列、不计正式票数和金额。
- date/seller/buyer：原件读取的日期与主体；amount是含税金额字符串；红字金额用负值。
- status：valid/red/void/unknown；verified=true需实际原件核对。未知状态或金额不计已核验净额；作废票须已核验作废状态才排除。
- files/sources：原件路径与来源索引，分享示例没有真实文件。多格式同号合并，主体/金额等冲突报错。
- order_ids：有依据的对应订单号；coverage_verified：已逐单/组件检查时才填true，不以金额相等为证据。
- components：实际涵盖餐费/运费等；红字/替换关系可另写相关票号。不同票号仍可能覆盖相同费用。
- potential_overlaps：待核票号/费用组件、金额及证据缺口；不自动扣减。仅金额相近不填已确认重复。

输出invoice_net_total、订单净支出、invoice_minus_expenditure和方向；正值是票额高于支出，负值是低于。完整覆盖须支出完整、票额完整、原件/匹配无待核、无可能重叠且总额一致。只满足总额一致不会被标完整。存在差额/待核退出2，但仍可输出正确核对报告；不是下载或平台失败。

本工具不验证原件文件真实、主体可报销或税务合规；执行者需读取原件并按业务流程审核。金额、匹配、文件列表输入全部由本次实际证据提供。
