#!/usr/bin/env python3
"""Compare invoice totals with verified expenditure; never infer coverage."""
import argparse
from decimal import Decimal, InvalidOperation
import importlib.util
import json
from pathlib import Path
import sys


def money(value):
    if not isinstance(value, (str, int)) or isinstance(value, bool):
        raise ValueError('金额须为字符串/整数，不使用浮点数')
    try:
        result = Decimal(value)
    except InvalidOperation:
        raise ValueError('无效发票金额') from None
    if not result.is_finite() or result != result.quantize(Decimal('0.01')):
        raise ValueError('发票金额须有限且精确到分')
    return result


def reconcile_invoices(ledger, data):
    if not isinstance(ledger, dict) or not isinstance(data, dict) or not isinstance(data.get('invoices'), list):
        raise ValueError('须提供订单汇总与invoices列表')
    currency = ledger.get('currency')
    if not currency or data.get('currency') != currency:
        raise ValueError('币种缺失或不一致；混币种分别核对')
    net = money(ledger.get('net_total'))
    orders = {r['order_id'] for r in ledger.get('orders', [])}
    required_orders = {r['order_id'] for r in ledger.get('orders', []) if r.get('net') is None or money(r['net']) > 0}
    covered_orders = set()
    seen, duplicates, rows, pending, receipts, mapping_pending = {}, [], [], [], [], []
    invoice_total = Decimal(0)
    for invoice in data['invoices']:
        if not isinstance(invoice, dict):
            raise ValueError('发票须为对象')
        if invoice.get('kind') == 'receipt':
            receipts.append(invoice)
            continue
        number = invoice.get('invoice_number')
        if not isinstance(number, str) or not number.isdigit():
            raise ValueError('正式票号须为数字字符串，不能用数值类型')
        if invoice.get('currency') != currency:
            raise ValueError('发票币种缺失或不一致：'+number)
        state = invoice.get('status')
        if state not in ('valid', 'red', 'void', 'unknown'):
            raise ValueError('status须为valid/red/void/unknown')
        if not isinstance(invoice.get('files', []), list):
            raise ValueError('files须为原件路径列表')
        if not isinstance(invoice.get('sources', []), list):
            raise ValueError('sources须为来源索引列表')
        core = {k:v for k,v in invoice.items() if k not in ('files', 'sources')}
        if number in seen:
            if core != seen[number]['core']:
                raise ValueError('同票号内容冲突，需核清原件：'+number)
            duplicates.append(number)
            for path in invoice.get('files', []):
                if path not in seen[number]['row']['files']:
                    seen[number]['row']['files'].append(path)
            for source in invoice.get('sources', []):
                if source not in seen[number]['row']['sources']:
                    seen[number]['row']['sources'].append(source)
            continue
        row = dict(invoice)
        row['files'] = list(invoice.get('files', []))
        row['sources'] = list(invoice.get('sources', []))
        seen[number] = {'core': core, 'row': row}
        rows.append(row)
        if invoice.get('verified') is not True or state == 'unknown' or (state != 'void' and invoice.get('amount') is None):
            pending.append({'invoice_number': number, 'reason': '状态/金额尚未核验，未计入正式净额'})
            continue
        if state == 'void':
            row['counted_amount'] = '0.00'
            continue
        amount = money(invoice['amount'])
        if (state == 'valid' and amount < 0) or (state == 'red' and amount >= 0):
            raise ValueError('正票须非负、红字票须负金额：'+number)
        invoice_total += amount
        row['counted_amount'] = format(amount, '.2f')
        matches = invoice.get('order_ids', [])
        if not isinstance(matches, list) or not all(isinstance(x, str) for x in matches):
            raise ValueError('order_ids须为字符串列表')
        if not matches or set(matches)-orders or invoice.get('coverage_verified') is not True:
            mapping_pending.append({'invoice_number': number, 'reason': '订单/费用组件覆盖未完整核验'})
        else:
            covered_orders.update(matches)
    for row in rows:
        if row.get('status') in ('valid', 'red') and 'counted_amount' in row and not row['files']:
            pending.append({'invoice_number': row['invoice_number'], 'reason': '未提供原件路径；金额已计，归档未完成'})
    uncovered_orders = sorted(required_orders-covered_orders)
    difference = invoice_total-net
    overlap = data.get('potential_overlaps', [])
    if not isinstance(overlap, list):
        raise ValueError('potential_overlaps须为待核说明列表')
    return {'currency': currency, 'expenditure_complete': ledger.get('complete') is True,
        'invoice_amounts_complete': not any('未计入' in x['reason'] for x in pending),
        'unique_invoice_count': len(rows), 'counted_invoice_count': sum(r.get('status') in ('valid','red') and 'counted_amount' in r for r in rows),
        'invoice_net_total': format(invoice_total, '.2f'), 'order_net_total': format(net, '.2f'),
        'invoice_minus_expenditure': format(difference, '.2f'),
        'difference_direction': '发票净额高于已核验支出' if difference>0 else '发票净额低于已核验支出' if difference<0 else '总额相等，仍须逐单覆盖核验',
        'invoices': rows, 'duplicate_invoice_numbers': duplicates, 'receipts_not_counted': receipts,
        'pending': pending, 'coverage_pending': mapping_pending, 'potential_overlaps': overlap,
        'orders_without_verified_coverage': uncovered_orders,
        'ready_for_final_reconciliation': ledger.get('complete') is True and not pending and not mapping_pending and not uncovered_orders and not overlap and difference == 0,
        'scope': '仅计算输入；差额和相等均不能自动认定漏票、重复开票、完整覆盖或可报销额'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('orders', type=Path)
    parser.add_argument('invoices', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        ledger = json.loads(args.orders.read_text())
        if 'net_total' not in ledger:
            script = Path(__file__).resolve().parents[2]/'order-cost-archive/scripts/summarize_orders.py'
            if not script.is_file():
                raise ValueError('独立安装请传入已核实net_total/currency/orders/complete的汇总文件，或同时安装order-cost-archive')
            spec = importlib.util.spec_from_file_location('expense_ledger', script)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            ledger = module.summarize_orders(ledger)
        result = reconcile_invoices(ledger, json.loads(args.invoices.read_text()))
        output = json.dumps(result, ensure_ascii=False, indent=2)+'\n'
        if args.output:
            args.output.write_text(output)
        else:
            print(output, end='')
        return 0 if result['ready_for_final_reconciliation'] else 2
    except (ValueError, TypeError, KeyError, OSError) as exc:
        print('发票核对尚未完成：'+str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
