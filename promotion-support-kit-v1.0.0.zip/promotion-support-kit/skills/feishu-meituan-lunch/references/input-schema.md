# V2通用输入与本地工具

工具只计算，不访问手机或外部应用。所有输入/输出留在当前项目，技能目录保留源工具。V1输入已归档，不能作本轮实时输入。

## 1. 饮品选择位分配（可选）

先据真实菜单建立groups：每个套餐/独立选择组的实际饮品位数及可选id；quantity是饮品选择位数，不是人数。例如双杯套餐3套有6个相同选择位；若两杯来自不同选择组则分成两组各3。

```json
{
  "groups": [
    {"id": "鸡排套餐饮品组", "quantity": 7, "eligible_drinks": ["water", "coffee"]},
    {"id": "汉堡套餐饮品组", "quantity": 5, "eligible_drinks": ["cola", "water"]}
  ],
  "drinks": [
    {"id": "water", "name": "矿泉水"},
    {"id": "coffee", "name": "美式", "stock": 10},
    {"id": "cola", "name": "可乐", "stock": 8}
  ],
  "policy": {"mode": "balanced", "remainder_mode": "spread", "allow_constraint_rebalance": false}
}
```

- `none`：无饮品选择位，groups总quantity必须0；不忽略套餐必选项。
- `exact`：policy.counts写每种饮品总数量，合计须等于选择位；固定配对可分别为每个固定组录输入，或直接形成SKU而跳过分配脚本。
- `balanced`：均分，余数默认spread；可用remainder_order设置当次允许选项的完整顺序；本次指定则`remainder_mode: designated`及`remainder_drink_id`，无具体饮品默认。
- 只有本次允许受限时调整，才`allow_constraint_rebalance: true`。理想杯数不可行时，在兼容/已知库存内最小化数量不均衡，并报告与理想的偏差；不改变规格、加价许可或固定搭配。未授权调整则返回不可行、缺多少位，退出2，不以部分结果当完成。
- stock为该分配集合内已核实上限；不填只表示输入未提供库存上限，不代表库存真实无限。最终仍需当前菜单核实。

```bash
python3 scripts/allocate_drinks.py 当次饮品输入.json --output 饮品分配.json
```

输出仅是选择位→饮品的分配，需要按本店真实套餐选择组与配对形成下面的SKU；不代表真实可售或已加购。多杯商品、固定糖度等实际规格由助手核对。

## 2. 通用SKU差量与数量校验

```json
{
  "schema_version": 2,
  "store_id": "本次实际分店的可识别ID",
  "existing_store_id": "本次实际分店的可识别ID",
  "participants": 5,
  "catalog_verified": true,
  "existing_cart_verified": true,
  "drink_catalog": {"coffee": "美式（热）", "water": "矿泉水"},
  "items": [
    {"id": "套餐A热美式", "name": "鸡排套餐", "spec": "标准份/不辣/热美式", "kind": "meal", "unit": "份", "quantity": 3, "available": true, "drink_units": {"coffee": 1}},
    {"id": "共享菜B", "name": "共享拼盘", "spec": "大份", "kind": "side", "unit": "盘", "quantity": 1, "available": true},
    {"id": "独立水", "name": "矿泉水", "spec": "500ml", "kind": "drink", "unit": "瓶", "quantity": 2, "available": true, "drink_units": {"water": 1}},
    {"id": "餐具", "name": "餐具", "spec": "1副", "kind": "utensil", "unit": "副", "quantity": 5, "available": true}
  ],
  "existing_items": [{"id": "套餐A热美式", "quantity": 1}],
  "count_checks": [{"name": "本次要求5杯瓶饮品", "drink_ids": ["coffee", "water"], "expected": 5}]
}
```

- 同店内同一商品不同规格/搭配必须不同SKU id；每个id映射必须由当前界面确认。
- kind可为meal/side/drink/utensil/other，销售单位任意；participants只作背景，不推导数量。
- drink_units表示每个销售单位实际含多少该id饮品：可为0、1、2、箱装数量等；独立饮品也须显式填写。名称写清杯/瓶和规格，混合单位报告不能合成同一种。
- count_checks可省略。只有明确的当次约束才写item_ids或drink_ids及expected，不能自动每人1份1杯。
- stock可选，提供时目标不可超库存。available和两种verified须真实已核实。
- existing_items先读取本店购物车；已有过量、范围外或门店不符返回待核清，不自动清空或删除。份数不足输出remaining_to_add。

```bash
python3 scripts/plan_cart.py 当次SKU输入.json --output 购物车差量.json
```

## 3. 实际购物车核验

```json
{
  "store_id": "本次实际分店的可识别ID",
  "items": [{"id": "套餐A热美式", "quantity": 3}, {"id": "共享菜B", "quantity": 1}, {"id": "独立水", "quantity": 2}, {"id": "餐具", "quantity": 5}],
  "fees": {"商品": "180.00", "打包": "10.00", "配送": "7.00", "优惠": "-20.00"},
  "checkout_total": "177.00"
}
```

fees分项可随店铺改变，优惠用负值。须用实际口径，商品已折扣时不要再次扣同一优惠。脚本校验SKU/规格/数量与费用加总，不自动核验地址、配送、真实库存和付款。

```bash
python3 scripts/plan_cart.py 当次SKU输入.json --observed 实际购物车.json --output 核验结果.json
```

退出0：本地所提供检查通过；无observed时仅代表计划生成。退出2：输入无效、需核清已有商品或实际核验不匹配，不是平台错误，不代表任务完成。

## 4. 25分钟计时

```bash
python3 scripts/budget.py start 当前项目/03_过程文件/计时.json --started-at '2026-10-06T11:00:00+08:00'
python3 scripts/budget.py status 当前项目/03_过程文件/计时.json
```

开始时间带时区，使用实际本轮开始时间；省略只记录首次可核验计时点，不等于收到指令。文件已存在禁止重置，不创建自动化。每阶段与故障后检查，15/18/20/25分钟节点按SOP执行。
