#!/usr/bin/env python3
"""Wall-clock lunch budget; local state only, no scheduler or background waits."""
import argparse
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sys

ZONE = timezone.utc


def timestamp(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('时间须带时区')
    return result.astimezone(ZONE)


def status(state, now):
    started = timestamp(state['started_at'])
    seconds = int((now - started).total_seconds())
    if seconds < 0:
        raise ValueError('开始时间晚于当前时间，请核清计时来源')
    if seconds >= 1500:
        action = '25分钟已到：交付完成/待审核/具体未完成状态；用户要求继续时继续执行并保留累计耗时，不冒充完成'
    elif seconds >= 1200:
        action = '20分钟已到：用户应已收到核对结果或接手清单；只有明确授权才进入下单'
    elif seconds >= 1080:
        action = '18分钟节点：立即提交核对结果，未完成则准确交接'
    elif seconds >= 900:
        action = '15分钟节点：进入结算核对；明显赶不上20分钟立即交接，不继续盲试'
    elif seconds >= 240:
        action = '按组合差量加购物车，每组合完成观察实际数量'
    elif seconds >= 120:
        action = '核票数、店铺、饮品、已有购物车及配送，生成计划'
    else:
        action = '完成合规启动、读票与连接；锁定立即交由用户本机验证'
    return {'started_at': state['started_at'], 'source': state['source'],
            'now': now.isoformat(timespec='seconds'), 'elapsed_seconds': seconds,
            'elapsed_minutes': round(seconds / 60, 2),
            'review_deadline': (started + timedelta(minutes=20)).isoformat(timespec='seconds'),
            'budget_checkpoint': (started + timedelta(minutes=25)).isoformat(timespec='seconds'),
            'review_remaining_seconds': max(0, 1200-seconds),
            'budget_remaining_seconds': max(0, 1500-seconds), 'action': action,
            'note': '等待/断连均计入墙钟；此工具不会创建自动化或执行付款'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    start = sub.add_parser('start')
    start.add_argument('state', type=Path)
    start.add_argument('--started-at')
    check = sub.add_parser('status')
    check.add_argument('state', type=Path)
    args = parser.parse_args()
    now = datetime.now(ZONE)
    try:
        if args.mode == 'start':
            started = timestamp(args.started_at) if args.started_at else now
            state = {'started_at': started.isoformat(timespec='seconds'),
                     'source': '用户指令时间或已核实开始时间' if args.started_at else
                               '首次可核验计时点；未代表收到用户指令时间'}
            result = status(state, now)
            # Exclusive creation prevents resetting the budget after reconnect.
            with args.state.open('x') as stream:
                json.dump(state, stream, ensure_ascii=False, indent=2)
                stream.write('\n')
        else:
            result = status(json.loads(args.state.read_text()), now)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, KeyError) as exc:
        print(f'计时未重置：{exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
