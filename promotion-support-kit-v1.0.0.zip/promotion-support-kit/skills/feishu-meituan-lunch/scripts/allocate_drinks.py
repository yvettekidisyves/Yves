#!/usr/bin/env python3
"""Local drink-slot allocation with store-specific choices and compatibility."""
import argparse
from collections import deque
import json
from pathlib import Path
import sys


def integer(value, field):
    if type(value) is not int or value < 0:
        raise ValueError(f'{field}须为非负整数')
    return value


def identity(value, field):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f'{field}须为非空id')
    return value.strip()


def allocate(data):
    if not isinstance(data, dict):
        raise ValueError('输入须为对象')
    groups = data.get('groups')
    choices = data.get('drinks')
    policy = data.get('policy')
    if not isinstance(groups, list) or not isinstance(choices, list) or not isinstance(policy, dict):
        raise ValueError('须有groups、drinks和policy')
    drinks = {}; demands = {}
    for choice in choices:
        if not isinstance(choice, dict):
            raise ValueError('每个饮品须为对象')
        key = identity(choice.get('id'), 'drink.id')
        if key in drinks:
            raise ValueError('饮品id重复')
        drinks[key] = dict(choice)
    for group in groups:
        if not isinstance(group, dict):
            raise ValueError('每个选择组须为对象')
        key = identity(group.get('id'), 'group.id')
        if key in demands:
            raise ValueError('组id重复')
        qty = integer(group.get('quantity'), '饮品选择位quantity（不是人数）')
        eligible = group.get('eligible_drinks')
        if not isinstance(eligible, list) or len(set(eligible)) != len(eligible) or set(eligible)-set(drinks):
            raise ValueError('eligible_drinks须为本组已核实可选饮品id')
        if qty and not eligible:
            raise ValueError(f'{key}有饮品需求但无可选项')
        demands[key] = {'quantity': qty, 'eligible': eligible}
    total = sum(g['quantity'] for g in demands.values())
    mode = policy.get('mode')
    if mode not in ('none', 'exact', 'balanced'):
        raise ValueError('mode须为none/exact/balanced')
    if mode == 'none':
        if total:
            raise ValueError('无饮品模式须先确认饮品选择位为0；必选饮品不可忽略')
        return {'feasible': True, 'total_drinks': 0, 'targets': {}, 'allocations': [], 'rebalanced': False}
    if not drinks and total:
        raise ValueError('有需求但当前无饮品选项')
    if mode == 'exact':
        raw = policy.get('counts')
        if not isinstance(raw, dict) or set(raw)-set(drinks):
            raise ValueError('指定杯数含未知饮品或未提供counts')
        targets = {k: integer(raw.get(k, 0), 'counts') for k in drinks}
        if sum(targets.values()) != total:
            raise ValueError('指定杯数不等于实际饮品选择位；不默认为人数')
    else:
        q, remainder = divmod(total, len(drinks)) if drinks else (0,0)
        targets = {k: q for k in drinks}
        strategy = policy.get('remainder_mode', 'spread')
        if strategy == 'designated':
            key = policy.get('remainder_drink_id')
            if key not in drinks:
                raise ValueError('本次指定余数饮品不在本店选项内')
            targets[key] += remainder
        elif strategy == 'spread':
            order = policy.get('remainder_order', list(drinks))
            if not isinstance(order, list) or len(order) != len(drinks) or set(order) != set(drinks):
                raise ValueError('remainder_order须是本次选项的完整不重复顺序')
            for key in order[:remainder]: targets[key] += 1
        else:
            raise ValueError('余数规则须为spread或本次指定designated')
    capacity = {k: integer(v.get('stock', total), 'drink.stock') for k,v in drinks.items()}

    def flow(relaxed=False):
        # Successive shortest paths. Convex marginal costs balance counts only
        # when the caller explicitly permits constraint rebalancing.
        names = ['source'] + [('g',k) for k in demands] + [('d',k) for k in drinks] + ['sink']
        ids = {k:i for i,k in enumerate(names)}; graph = [[] for _ in names]
        source, sink = ids['source'], ids['sink']; refs = {}
        def edge(u,v,cap,cost):
            forward = [v,len(graph[v]),cap,cost,cap]
            backward = [u,len(graph[u]),0,-cost,0]
            graph[u].append(forward); graph[v].append(backward)
            return forward
        for key,g in demands.items():
            edge(source,ids[('g',key)],g['quantity'],0)
            for drink in g['eligible']:
                refs[(key,drink)] = edge(ids[('g',key)],ids[('d',drink)],g['quantity'],0)
        scale = total*max(1,len(drinks))+1
        for rank,key in enumerate(drinks):
            cap = min(capacity[key],total) if relaxed else min(capacity[key],targets[key])
            if relaxed:
                for nth in range(cap): edge(ids[('d',key)],sink,1,(2*nth+1)*scale+rank)
            else:
                edge(ids[('d',key)],sink,cap,0)
        sent=0
        while sent < total:
            dist=[float('inf')]*len(names); dist[source]=0; prev=[None]*len(names)
            queue=deque([source]); queued={source}
            while queue:
                u=queue.popleft(); queued.discard(u)
                for index,e in enumerate(graph[u]):
                    v,rev,cap,cost,_=e
                    if cap and dist[v] > dist[u]+cost:
                        dist[v]=dist[u]+cost; prev[v]=(u,index)
                        if v not in queued: queue.append(v); queued.add(v)
            if prev[sink] is None: break
            amount=total-sent; node=sink
            while node != source:
                u,index=prev[node]; amount=min(amount,graph[u][index][2]); node=u
            node=sink
            while node != source:
                u,index=prev[node]; e=graph[u][index]; e[2]-=amount; graph[node][e[1]][2]+=amount; node=u
            sent+=amount
        rows=[{'group_id':g,'drink_id':d,'quantity':e[4]-e[2]}
              for (g,d),e in refs.items() if e[4]-e[2]]
        return sent,rows

    sent, rows = flow()
    rebalanced=False
    if sent < total and mode == 'balanced' and policy.get('allow_constraint_rebalance') is True:
        sent, rows = flow(True); rebalanced=True
    actual={k:0 for k in drinks}
    for row in rows: actual[row['drink_id']]+=row['quantity']
    return {'feasible':sent==total, 'total_drinks':total, 'ideal_targets':targets,
            'targets':actual if sent==total else None, 'allocations':rows,
            'unfulfilled_drink_slots':total-sent, 'rebalanced':rebalanced,
            'deviations_from_ideal':{k:actual[k]-targets[k] for k in drinks if actual[k]!=targets[k]},
            'note':'仅分配饮品选择位；须按本店实际套餐选择组/规格生成商品SKU，不代表已加购。不可行时不把部分分配当完成。'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path); parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    try:
        result=allocate(json.loads(args.input.read_text()))
        output=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
        if args.output: args.output.write_text(output); print(f'饮品计划已保存：{args.output}')
        else: print(output,end='')
        return 0 if result['feasible'] else 2
    except (ValueError,OSError,TypeError,KeyError) as exc:
        print(f'未执行饮品购买：{exc}',file=sys.stderr); return 2


if __name__=='__main__':
    sys.exit(main())
