#!/usr/bin/env python3
"""Generic local SKU cart diff and quantity/fee checks. Never changes a cart."""
import argparse
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import sys


def integer(value, field, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f'{field}须为不小于{minimum}的整数')
    return value


def text(value, field):
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f'{field}须为非空文本')
    return value.strip()


def quantities(rows):
    if not isinstance(rows, list):
        raise ValueError('实际/已有商品须为列表')
    result = Counter()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError('商品须为对象')
        result[text(row.get('id'), '商品id')] += integer(row.get('quantity'), 'quantity')
    return result


def metrics(catalog, counts):
    units = defaultdict(Counter)
    drinks = Counter()
    for key, item in catalog.items():
        qty = counts.get(key, 0)
        units[item['kind']][item['unit']] += qty
        for drink, per_unit in item['drink_units'].items():
            drinks[drink] += qty * per_unit
    return {'units_by_kind': {k: dict(v) for k, v in units.items()}, 'drink_units': dict(drinks)}


def allocate(data):
    if not isinstance(data, dict) or data.get('schema_version') != 2:
        raise ValueError('请用通用版schema_version=2；V1历史输入不可当作实时通用输入')
    if data.get('catalog_verified') is not True or data.get('existing_cart_verified') is not True:
        raise ValueError('须先核实当前门店菜单与已有购物车')
    store_id = text(data.get('store_id'), 'store_id')
    if data.get('existing_store_id') != store_id:
        raise ValueError('已有购物车门店不匹配，不能跨店合并')
    participants = integer(data.get('participants'), 'participants')
    rows = data.get('items')
    if not isinstance(rows, list):
        raise ValueError('items须为列表')
    drinks = data.get('drink_catalog', {})
    if not isinstance(drinks, dict):
        raise ValueError('drink_catalog须为id到名称的对象')
    drink_catalog = {text(k, 'drink id'): text(v, 'drink name') for k, v in drinks.items()}
    catalog = {}
    target = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError('item须为对象')
        key = text(row.get('id'), 'item.id')
        if key in catalog:
            raise ValueError(f'重复SKU：{key}；不同规格必须用不同id')
        kind = row.get('kind')
        if kind not in ('meal', 'side', 'drink', 'utensil', 'other'):
            raise ValueError('kind须为meal/side/drink/utensil/other')
        qty = integer(row.get('quantity'), 'item.quantity')
        if qty and row.get('available') is not True:
            raise ValueError(f'{key}可售状态未核实或不可售')
        if 'stock' in row and qty > integer(row['stock'], 'stock'):
            raise ValueError(f'{key}需求超过已知库存，需处理缺货')
        included = row.get('drink_units', {})
        if not isinstance(included, dict):
            raise ValueError('drink_units须为饮品id到每个销售单位内数量的对象')
        included = {text(k, 'drink id'): integer(v, '每销售单位饮品数') for k, v in included.items()}
        if set(included) - set(drink_catalog):
            raise ValueError('drink_units存在未知饮品id')
        if kind == 'drink' and qty and not any(included.values()):
            raise ValueError('独立饮品须明确每个销售单位含多少杯/瓶，不默认为1')
        catalog[key] = {'id': key, 'name': text(row.get('name'), 'item.name'),
                        'spec': text(row.get('spec'), 'item.spec（无规格填默认）'),
                        'kind': kind, 'unit': text(row.get('unit'), 'item.unit'),
                        'drink_units': included}
        target[key] = qty
    expected_metrics = metrics(catalog, target)
    checks = data.get('count_checks', [])
    if not isinstance(checks, list):
        raise ValueError('count_checks须为列表')
    for check in checks:
        ids = check.get('item_ids')
        drink_ids = check.get('drink_ids')
        if (ids is None) == (drink_ids is None):
            raise ValueError('数量检查须指定item_ids或drink_ids之一')
        expected = integer(check.get('expected'), '检查expected')
        keys = ids if ids is not None else drink_ids
        source = target if ids is not None else expected_metrics['drink_units']
        valid = catalog if ids is not None else drink_catalog
        if not isinstance(keys, list) or len(set(keys)) != len(keys) or set(keys)-set(valid):
            raise ValueError('数量检查id不合法或重复')
        if sum(source.get(key, 0) for key in keys) != expected:
            raise ValueError(f'本轮数量约束不符：{check.get("name", "数量检查")}')
    existing = quantities(data.get('existing_items'))
    unknown = {key: qty for key, qty in existing.items() if key not in target and qty}
    excess = {key: existing[key]-qty for key, qty in target.items() if existing[key] > qty}
    additions = [dict(catalog[key], quantity=qty-existing[key])
                 for key, qty in target.items() if qty > existing[key]]
    return {'schema_version': 2, 'status': '仅计算差量，未进行真实加购',
            'store_id': store_id, 'participants': participants,
            'catalog': catalog, 'target_quantities': target, 'drink_catalog': drink_catalog,
            'target_metrics': expected_metrics, 'count_checks': checks,
            'remaining_to_add': additions, 'excess_existing': excess,
            'unscoped_existing': unknown,
            'requires_reconciliation': bool(excess or unknown),
            'note': '人数不推导商品份数或饮品数；过量/范围外商品须核清，脚本不清空、不删除、不付款'}


def verify(plan, observed):
    if not isinstance(observed, dict):
        raise ValueError('observed须为对象')
    actual = quantities(observed.get('items'))
    target = plan['target_quantities']
    differences = {key: {'expected': target.get(key, 0), 'actual': actual.get(key, 0)}
                   for key in set(target) | set(actual) if target.get(key, 0) != actual.get(key, 0)}
    issues = []
    if observed.get('store_id') != plan['store_id']:
        issues.append('实际购物车门店不符')
    if differences:
        issues.append('实际SKU及数量不匹配（包括规格/餐具/范围外商品）')
    fee_matches, fee_sum = None, None
    if 'fees' in observed:
        if not isinstance(observed['fees'], dict) or not observed['fees']:
            raise ValueError('fees须为非空金额分项对象')
        try:
            values = [Decimal(str(v)) for v in observed['fees'].values()]
            total = Decimal(str(observed['checkout_total']))
        except (InvalidOperation, KeyError, TypeError):
            raise ValueError('费用无有效金额') from None
        if any(not v.is_finite() for v in values+[total]) or total < 0:
            raise ValueError('金额须有限，结算总额不可为负；优惠以负项明确计入')
        fee_sum = sum(values, Decimal('0'))
        fee_matches = abs(fee_sum-total) < Decimal('0.005')
        if not fee_matches:
            issues.append('费用分项合计与结算总额不符')
    return {'success': not issues, 'differences': differences,
            'actual_metrics': metrics(plan['catalog'], actual),
            'fee_sum_matches': fee_matches, 'fee_sum': str(fee_sum) if fee_sum is not None else None,
            'issues': issues, 'scope': '仅本地输入校验；实际规格映射、地址、配送、库存和付款状态须界面独立核实'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--observed', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        plan = allocate(json.loads(args.input.read_text()))
        if args.observed:
            plan['verification'] = verify(plan, json.loads(args.observed.read_text()))
        result = json.dumps(plan, ensure_ascii=False, indent=2)+'\n'
        if args.output:
            args.output.write_text(result)
            print(f'已保存差量：{args.output}；新增SKU {len(plan["remaining_to_add"])}种')
        else:
            print(result, end='')
        return 2 if plan['requires_reconciliation'] or (args.observed and not plan['verification']['success']) else 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(f'未执行加购：{exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
