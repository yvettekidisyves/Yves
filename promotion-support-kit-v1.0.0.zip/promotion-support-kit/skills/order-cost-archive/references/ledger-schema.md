# 订单费用输入

参考[合成账本](../assets/orders.synthetic.json)。金额统一用精确到分的字符串，订单号用字符串；账本currency与每单currency一致，混币种分别计算，不假设汇率。

每单：order_id、date、category、store、period、destination、status、verified、paid、refund_received和screenshots。状态可paid/completed/refunded/cancelled/unpaid/user_reported_paid。verified=true只能据正式平台订单；未知paid或refund_received用null，不能默认0。未支付明确paid=0/refund_received=0；零实付优惠单须另有zero_paid_verified=true的实际证据。

refund_received仅已经到账退款；refund_pending等说明字段不自动扣减。已付但取消的订单仍按实付和真实退款计账。退款超过实付报错；额外补偿等其他口径另列，不能混入订单退款。

同order_id重复且内容相同只计一次，screenshots/evidence可补原件；金额或状态等核心内容冲突要求回读修正输入，不自动判新旧。文件路径仅是索引，脚本不证明文件存在或图片真实；输出missing_screenshot_order_ids提示凭据缺失。

输出paid_total、refund_received_total、net_total、逐单和分日期/类别合计。complete仅表示所有所给订单的金额和状态已被输入标为核实，不表示平台日期范围已穷尽或归档已上传。输入不全退出2并仅报告已核验小计；空列表可合法得0，但用户要“这些天所有单”时先独立确认范围真的为空。
