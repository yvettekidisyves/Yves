#!/usr/bin/env python3
"""Summarize verified paid orders and received refunds. Local files only."""
import argparse
from collections import defaultdict
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import sys


def money(value, field, allow_negative=False):
    if not isinstance(value, (str, int)) or isinstance(value, bool):
        raise ValueError(field+'须为金额字符串（或整数），不使用浮点数')
    try:
        amount = Decimal(value)
    except InvalidOperation:
        raise ValueError(field+'无效金额') from None
    if not amount.is_finite() or amount != amount.quantize(Decimal('0.01')) or (amount < 0 and not allow_negative):
        raise ValueError(field+'须为有限、精确到分的有效金额')
    return amount


def summarize_orders(data):
    if not isinstance(data, dict) or not isinstance(data.get('orders'), list):
        raise ValueError('输入须有orders列表')
    currency = data.get('currency')
    if not isinstance(currency, str) or not currency.strip():
        raise ValueError('必须明确单一币种，混币种分别建账')
    seen, duplicates, pending, rows = {}, [], [], []
    totals = defaultdict(lambda: {'paid': Decimal(0), 'refund': Decimal(0), 'count': 0})
    for order in data['orders']:
        if not isinstance(order, dict):
            raise ValueError('订单须为对象')
        key = order.get('order_id')
        if not isinstance(key, str) or not key.strip():
            raise ValueError('order_id须为非空字符串，未核验订单号不能计入正式账本')
        if order.get('currency') != currency:
            raise ValueError('订单币种缺失或与账本不符：'+key)
        core = {k:v for k,v in order.items() if k not in ('screenshots', 'evidence')}
        if key in seen:
            if core != seen[key]['core']:
                raise ValueError('同订单号内容冲突，先回读正式订单：'+key)
            duplicates.append(key)
            for shot in order.get('screenshots', []):
                if shot not in seen[key]['row']['screenshots']:
                    seen[key]['row']['screenshots'].append(shot)
            continue
        if not isinstance(order.get('screenshots', []), list):
            raise ValueError('screenshots须为文件/链接列表')
        row = dict(order)
        row['screenshots'] = list(order.get('screenshots', []))
        seen[key] = {'core': core, 'row': row}
        status = order.get('status')
        if status not in ('paid', 'completed', 'refunded', 'cancelled', 'unpaid', 'user_reported_paid'):
            raise ValueError('未知订单status：'+key)
        if order.get('verified') is not True or order.get('paid') is None or order.get('refund_received') is None or status == 'user_reported_paid':
            pending.append({'order_id': key, 'reason': '正式金额/状态或到账退款尚未核验，未计入合计'})
            continue
        paid = money(order['paid'], 'paid')
        refund = money(order['refund_received'], 'refund_received')
        if refund > paid:
            raise ValueError('到账退款大于实付，需核清费用口径：'+key)
        if status == 'unpaid' and (paid or refund):
            raise ValueError('unpaid状态不可有实付/退款：'+key)
        if status in ('paid', 'completed', 'refunded') and paid == 0:
            # Zero-payment promotions are valid only with explicit proof.
            if order.get('zero_paid_verified') is not True:
                raise ValueError('零实付须有明确订单证据：'+key)
        if not isinstance(order.get('date'), str) or not isinstance(order.get('category'), str):
            raise ValueError('订单须有date与category')
        row.update(paid=str(paid.quantize(Decimal('0.01'))), refund_received=str(refund.quantize(Decimal('0.01'))), net=str((paid-refund).quantize(Decimal('0.01'))))
        rows.append(row)
        for group in [('date', order['date']), ('category', order['category']), ('all', 'all')]:
            totals[group]['paid'] += paid
            totals[group]['refund'] += refund
            totals[group]['count'] += 1
    all_totals = totals[('all', 'all')]
    def render(value):
        return {'order_count': value['count'], 'paid_total': format(value['paid'], '.2f'),
            'refund_received_total': format(value['refund'], '.2f'),
            'net_total': format(value['paid']-value['refund'], '.2f')}
    return {'currency': currency, 'complete': not pending, **render(all_totals), 'orders': rows,
        'by_date': {k[1]: render(v) for k,v in totals.items() if k[0]=='date'},
        'by_category': {k[1]: render(v) for k,v in totals.items() if k[0]=='category'},
        'pending': pending, 'duplicate_order_ids': duplicates,
        'missing_screenshot_order_ids': [r['order_id'] for r in rows if not r['screenshots']],
        'scope': '仅输入计算；screenshots路径存在、图像可读与真实支付仍需独立核验'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        result = summarize_orders(json.loads(args.input.read_text()))
        output = json.dumps(result, ensure_ascii=False, indent=2)+'\n'
        if args.output:
            args.output.write_text(output)
        else:
            print(output, end='')
        return 0 if result['complete'] else 2
    except (ValueError, TypeError, OSError) as exc:
        print('账本未完成核验：'+str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
