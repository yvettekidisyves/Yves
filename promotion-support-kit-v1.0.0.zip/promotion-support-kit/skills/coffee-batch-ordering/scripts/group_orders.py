#!/usr/bin/env python3
"""Group a complete, human-parsed coffee snapshot. Local files only."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys


def group_orders(data):
    if not isinstance(data, dict) or not isinstance(data.get('entries'), list):
        raise ValueError('输入须有entries列表')
    rules = data.get('rules', {})
    if not isinstance(rules, dict):
        raise ValueError('rules须为对象')
    destinations = data.get('destinations')
    if not isinstance(destinations, list) or not all(isinstance(x, str) and x.strip() for x in destinations) or len(set(destinations)) != len(destinations):
        raise ValueError('destinations须为本次已核实的不同地点标识')
    if rules.get('default_period') not in (None, 'morning', 'afternoon'):
        raise ValueError('default_period须为morning/afternoon/null')
    if rules.get('default_destination') not in [None]+destinations:
        raise ValueError('默认地点不在本次地点内')
    for field in ('include_templates', 'include_late'):
        if rules.get(field) is not None and type(rules[field]) is not bool:
            raise ValueError(field+'须为布尔或null')
    pending, excluded, duplicates = [], [], []
    groups = Counter()
    contributors = {}
    seen = {}
    raw_cups = 0
    for entry in data['entries']:
        if not isinstance(entry, dict):
            raise ValueError('entry须为对象')
        key = entry.get('entry_id')
        if not isinstance(key, str) or not key.strip():
            raise ValueError('entry_id须为唯一非空字符串；同记录多行用不同entry_id')
        qty = entry.get('quantity')
        if type(qty) is not int or qty <= 0:
            raise ValueError('quantity须为正整数杯数')
        if key in seen:
            if entry != seen[key]:
                raise ValueError('同entry_id数据冲突：'+key)
            duplicates.append(key)
            continue
        seen[key] = entry
        raw_cups += qty
        for flag in ('is_template', 'is_late', 'cancelled'):
            if flag in entry and type(entry[flag]) is not bool:
                raise ValueError(flag+'须为布尔值')
        if entry.get('cancelled') is True:
            excluded.append({'entry_id': key, 'quantity': qty, 'reason': '已核实取消'})
            continue
        reasons = []
        exclude_reason = None
        for flag, rule in [('is_template', 'include_templates'), ('is_late', 'include_late')]:
            if entry.get(flag) is True:
                if rules.get(rule) is False:
                    exclude_reason = rule+'为false（当前已确认规则）'
                elif rules.get(rule) is not True:
                    reasons.append(rule+'尚未确认')
        if exclude_reason:
            excluded.append({'entry_id': key, 'quantity': qty, 'reason': exclude_reason})
            continue
        period = entry.get('period') or rules.get('default_period')
        destination = entry.get('destination') or rules.get('default_destination')
        if period not in ('morning', 'afternoon'):
            reasons.append('时段缺失或无效')
        if destination not in destinations:
            reasons.append('地点缺失或未核实')
        spec = entry.get('spec')
        if not isinstance(spec, dict):
            spec = {}
        fields = ('brand', 'name', 'size', 'ice', 'sweetness')
        for field in fields:
            if not isinstance(spec.get(field), str) or not spec[field].strip():
                reasons.append('缺少完整规格：'+field)
        extras = spec.get('extras')
        if not isinstance(extras, list) or not all(isinstance(x, str) and x.strip() for x in extras):
            reasons.append('extras须明确为备注列表；无备注用[]')
            extras = []
        if reasons:
            pending.append({'entry_id': key, 'quantity': qty, 'reasons': reasons})
            continue
        group = (period, destination, *(spec[f].strip() for f in fields), tuple(sorted(extras)))
        groups[group] += qty
        contributors.setdefault(group, []).append(key)
    rows = []
    totals = Counter()
    for key, qty in sorted(groups.items()):
        period, destination, brand, name, size, ice, sweetness, extras = key
        rows.append({'period': period, 'destination': destination, 'quantity': qty,
            'spec': dict(brand=brand, name=name, size=size, ice=ice, sweetness=sweetness, extras=list(extras)),
            'entry_ids': contributors[key]})
        totals[(period, destination)] += qty
    complete = data.get('source_complete') is True
    return {'source_complete': complete, 'source_snapshot_at': data.get('snapshot_at'),
        'ready_for_confirmation': complete and not pending,
        'raw_unique_cups': raw_cups, 'included_cups': sum(groups.values()),
        'excluded_cups': sum(x['quantity'] for x in excluded),
        'pending_cups': sum(x['quantity'] for x in pending),
        'totals': [{'period': p, 'destination': d, 'cups': n} for (p,d), n in sorted(totals.items())],
        'items': rows, 'pending': pending, 'excluded': excluded, 'duplicate_entry_ids': duplicates,
        'issues': [] if complete else ['来源未证明已读完全部记录/分页；不能作为完整统计'],
        'scope': '仅计算输入；未核实实时菜单库存，未加购、下单或付款'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        result = group_orders(json.loads(args.input.read_text()))
        output = json.dumps(result, ensure_ascii=False, indent=2)+'\n'
        if args.output:
            args.output.write_text(output)
        else:
            print(output, end='')
        return 0 if result['ready_for_confirmation'] else 2
    except (ValueError, TypeError, OSError) as exc:
        print('未执行点单：'+str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
