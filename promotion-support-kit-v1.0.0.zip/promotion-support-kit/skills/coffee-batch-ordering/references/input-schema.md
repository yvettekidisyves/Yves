# 咖啡统计输入

参考[合成示例](../assets/coffee.synthetic.json)，它仅演示字段，示例地址/品牌/日期都不是可执行指令。

- source_complete：已读取全部来源与分页时才填true；snapshot_at为真实快照时刻。
- destinations：本次已核实地点标识，不存实际详细地址；在私有配送配置中映射。
- rules.default_period/default_destination：只填本次已公告或用户确认的默认；否则null。
- rules.include_templates/include_late：是否纳入本人模板或迟到需求，已确认则true/false，未确认null。不会凭截止时间自动判定，来源解析时提供is_late。
- entries：每个唯一entry_id对应一行规格，source_record_id指向原记录；同记录多规格使用不同entry_id。quantity为正整数杯数；raw_text保留原文，参与者可另留私有来源表。两个人相同规格仍有不同entry_id，不因相同规格去掉需求。
- period：morning/afternoon；destination从本次地点中选择；没填且无已确认默认就列待核。
- spec：brand/name/size/ice/sweetness均须明确字符串，extras须列表（无额外要求用[]）。菜单实际不适用的字段可填“菜单不适用”，不能为凑格式捏造糖度。
- is_template/is_late/cancelled：按实际来源核实布尔值；未出现默认false只表示解析者未标注该旗标，执行者须确保原始来源已核对。cancelled=true仅用于已核实取消。

同entry_id完全重复只计算一次；数据冲突报错。不同entry_id的相同完整规格会合计杯数并保留贡献行ID。脚本不读飞书、不根据姓名猜团队，不查询菜单、不均分指定咖啡。

输出included/excluded/pending杯数之和等于去重后原始杯数；来源不全或pending非空则ready_for_confirmation=false和退出2。部分汇总可以展示为部分，不能据此声称完整准备点单。
